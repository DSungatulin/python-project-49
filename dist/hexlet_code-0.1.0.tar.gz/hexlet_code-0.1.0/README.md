### Hexlet tests and linter status:
[![Actions Status](https://github.com/DSungatulin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DSungatulin/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2581ad2594ed7cb96796/maintainability)](https://codeclimate.com/github/DSungatulin/python-project-49/maintainability)
https://asciinema.org/a/0lqhiS7oLTiEUczai7orFo374
https://asciinema.org/a/O6ST9KtLmnbutSaJE1xpFQjcK
https://asciinema.org/a/1WSLwxd4n86j4DErTLfBUdiob
https://asciinema.org/a/UMtXQne3tJk7ktusQPIzb3H2G
https://asciinema.org/a/7NEVaLj8rFOAoryR38MhCHF4c